from fractions import Fraction as F
from math import sqrt,log
import pytest
from hmmcert.exact import sqrt_upper, log_upper, ceil_log2, solve_linear


def test_outward_sqrt_and_log():
    for x in [F(0),F(1,2),F(2),F(100,3)]:
        u=sqrt_upper(x)
        assert u*u>=x and u>=0
        assert float(u)-sqrt(float(x))<1e-12
    for x in [F(1),F(2),F(9,5),F(100000)]:
        u=log_upper(x)
        assert float(u)>=log(float(x))-1e-12
        assert float(u)-log(float(x))<1e-8
    assert ceil_log2(F(9,4))==2
    assert ceil_log2(F(8))==3


def test_gauss():
    x=solve_linear([[F(2),F(1)],[F(3),F(2)]],[F(5),F(8)])
    assert x==(F(2),F(1))
