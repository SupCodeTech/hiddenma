from fractions import Fraction as F
from hmmcert.confidence import (refresh_radii, in_refresh_region, block_radius,
 in_block_region, lr_ratio, in_lr_region, empirical_blocks)
from hmmcert.geometry import refresh_vertices,diameter_approx


def test_outward_refresh_radii(model):
    assert refresh_radii(model,[0,1,0],F(1,20))==(F(1),F(1))
    assert all(F(0)<=x<=1 for x in refresh_radii(model,[1]*300,F(1,20)))
    assert len(refresh_vertices(model,[1]*20))>=1


def test_polytope_clips_on_large_prefix(model):
    obs=[1]*10000
    vertices=refresh_vertices(model,obs,F(1,20))
    # An impossible-looking empirical frequency legitimately yields the empty set.
    assert len(vertices)==0
    assert not in_refresh_region(model,obs,(F(3,10),F(3,10),F(2,5)))


def test_block_frequency(model):
    hmm=model.hmm()
    obs=[0,1,1,0,0,1,0]
    freq=empirical_blocks(obs,2,hmm.b)
    assert len(freq)==hmm.b+hmm.b**2
    assert sum(v for w,v in freq.items() if len(w)==2)==1
    assert block_radius(hmm,len(obs),2)>0
    assert isinstance(in_block_region(hmm,obs,(F(1,3),)*3,2),bool)


def test_lr_reference_mixture_contains_support_somewhere(model):
    hmm=model.hmm()
    obs=[0,1,0,1,1,0]
    ref=[((F(1),F(0),F(0)),F(1,3)),((F(0),F(1),F(0)),F(1,3)),
         ((F(0),F(0),F(1)),F(1,3))]
    ratios=[lr_ratio(hmm,obs,theta,ref) for theta,w in ref]
    assert min(ratios)<=1
    assert any(in_lr_region(hmm,obs,theta,ref) for theta,w in ref)
