from fractions import Fraction as F
import pytest
from hmmcert import AffineRefresh
from hmmcert.identifiability import posterior_equivalent_for_pair, sensitivity_bound


def test_signature_exact_rank_deficient(model):
    q=model.signature_modes()
    for s in [F(0),F(1,5),F(3,5),F(1)]:
        theta=(s,F(0),1-s)
        assert model.signature(theta)[1]==F(14,25)-s/5
    assert q[0]==q[1]
    assert q[0]!=q[2]


def test_same_fiber_has_same_stress_filter(model):
    obs=(1,0,1,0,0,1,1,1,0,1)
    theta=(F(1,5),F(2,5),F(2,5))
    theta_prime=(F(2,5),F(1,5),F(2,5))
    hmm=model.hmm()
    assert hmm.target(obs,theta)==hmm.target(obs,theta_prime)
    assert hmm.filter(obs,theta)[0][0]!=hmm.filter(obs,theta_prime)[0][0]
    assert posterior_equivalent_for_pair(hmm,theta,theta_prime)[0]
    assert not posterior_equivalent_for_pair(hmm,theta,(F(4,5),F(0),F(1,5)))[0]


def test_sample_valid(model):
    hmm=model.hmm()
    obs,states=hmm.sample((F(3,10),F(3,10),F(2,5)),35,42)
    assert len(obs)==len(states)==35
    assert all(0<=y<hmm.b for y in obs)
    assert all(0<=z<hmm.S for z in states)
    assert hmm.filter(obs,(F(3,10),F(3,10),F(2,5)))[1]>0
    assert sensitivity_bound(hmm)["L_phi_upper"]>0


def test_finance_matrix_exact(finance):
    for q in finance.signature_modes():
        assert sum(q)==1
    for mode in finance.hmm().modes:
        assert all(sum(row)==1 for row in mode)
