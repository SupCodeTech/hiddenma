"""Tests for the any-K geometry, the strengthened verifier and the fast equivalence test."""
import json
import random
from copy import deepcopy
from fractions import Fraction as F
from hashlib import sha256
import pytest
from hmmcert import AffineRefresh, SolverSettings, solve
from hmmcert.exact import dot, solve_linear
from hmmcert.geometry import (refresh_vertices, general_region, refresh_region, region_volume,
                              simplex_volume, triangulate, free_constraints, enumerate_vertices)
from hmmcert.certificate import build_certificate, verify_certificate, _canonical
from hmmcert.identifiability import posterior_equivalent_for_pair, posterior_equivalent_bruteforce
from conftest import ROOT

CLIPPING_RD = [[1]*4400+[0]*5600, [1]*3000+[0]*7000, [1]*5600+[0]*4400, [0, 1]*20]


@pytest.mark.parametrize("obs", CLIPPING_RD)
def test_general_algorithm_reproduces_2d_clipping(model, obs):
    old = refresh_vertices(model, obs)
    new, cells = general_region(model, obs)
    assert set(old) == set(new)
    fan = sum((simplex_volume(c) for c in triangulate(old)), F(0))
    assert sum((simplex_volume(c) for c in cells), F(0)) == fan == region_volume(model, obs)


def test_full_simplex_shortcut_and_empty_region(four_mode):
    vertices, cells = refresh_region(four_mode, [0, 1, 0, 1])
    assert len(vertices) == 4 and len(cells) == 1 and len(cells[0].vertices) == 4
    assert refresh_region(four_mode, [1]*10000) == ((), ())


def _clipped_four_mode_prefix(model):
    obs, _ = model.hmm().sample((F(1, 10), F(1, 10), F(7, 10), F(1, 10)), 6000, seed=3)
    return obs


def _barycentric_inside(cell, x):
    """Is the free-coordinate point x inside the full-dimensional simplex `cell`?"""
    v = [w[:-1] for w in cell.vertices]
    d = len(x)
    A = [[v[j][i]-v[0][i] for j in range(1, d+1)] for i in range(d)]
    lam = solve_linear(A, [x[i]-v[0][i] for i in range(d)])
    return all(l >= 0 for l in lam) and sum(lam) <= 1


def test_four_mode_clipped_region_is_exactly_covered(four_mode):
    obs = _clipped_four_mode_prefix(four_mode)
    vertices, cells = refresh_region(four_mode, obs)
    assert len(vertices) > 4, "test prefix should clip the simplex"
    vol = sum((simplex_volume(c) for c in cells), F(0))
    assert vol > 0 and vol == region_volume(four_mode, obs)
    rows = free_constraints(four_mode, obs)
    assert all(all(dot(c, w[:-1]) <= r for c, r in rows) for cell in cells for w in cell.vertices)
    # Direct coverage test: random feasible rational points must lie in some cell.
    rng = random.Random(0)
    hits = 0
    for _ in range(400):
        x = tuple(F(rng.randint(0, 60), 60) for _ in range(3))
        if sum(x) > 1 or not all(dot(c, x) <= r for c, r in rows):
            continue
        hits += 1
        assert any(_barycentric_inside(c, x) for c in cells if simplex_volume(c) > 0)
    assert hits > 5


def test_four_mode_solve_brackets_true_targets_and_verifies(four_mode):
    hmm = four_mode.hmm()
    obs, _ = hmm.sample((F(1, 4),)*4, 30, seed=11)
    result = solve(four_mode, obs, SolverSettings(epsilon=F(1, 100), max_memory=8, max_cells=60))
    # outer bounds are mathematically valid whether or not the gap budget was met
    assert result.status in ("certified", "resource-limited")
    L, U, inner_L, inner_U = result.bounds
    for a in range(5):
        for b in range(5-a):
            for c in range(5-a-b):
                theta = (F(a, 4), F(b, 4), F(c, 4), 1-F(a+b+c, 4))
                assert L <= hmm.target(obs, theta) <= U
    report = verify_certificate(build_certificate(four_mode, result))
    assert report["valid"] and len(report["independent_checks"]) == 3


def _resign(cert):
    data = {k: v for k, v in cert.items() if k != "sha256"}
    cert["sha256"] = sha256(_canonical(data).encode("utf-8")).hexdigest()
    return cert


def test_resigned_tampering_is_still_caught(model):
    """A forger who recomputes the SHA-256 must still be stopped by the replay."""
    obs = [0, 1, 1, 0, 1, 0, 0, 1, 1, 0]*3            # t=30 > m=12, so the forgetting gap is > 0
    result = solve(model, obs, SolverSettings(max_memory=12))
    assert min(result.gaps) > F(1, 10**10)
    cert = build_certificate(model, result)
    bad = deepcopy(cert)
    bad["result"]["bounds"][0] = "0"
    with pytest.raises(ValueError, match="endpoint"):
        verify_certificate(_resign(bad))
    bad = deepcopy(cert)
    bad["result"]["status"] = "certified"
    bad["result"]["settings"]["epsilon"] = "1/10000000000"
    with pytest.raises(ValueError):
        verify_certificate(_resign(bad))


def test_version1_certificate_still_verifies():
    cert = json.loads((ROOT/"examples"/"sample_certificate.json").read_text())
    assert cert["schema"] == "hmmcert-v1"
    assert verify_certificate(cert)["valid"]


def test_fast_equivalence_matches_bruteforce(model):
    hmm = model.hmm()
    rng = random.Random(5)
    for _ in range(8):
        a, b, s = rng.randint(0, 10), rng.randint(0, 10), rng.randint(0, 20)
        same_fiber = ((F(a, 20), F(10-a, 20), F(1, 2)), (F(b, 20), F(10-b, 20), F(1, 2)))
        other = ((F(a, 20), F(10-a, 20), F(1, 2)), (F(s, 20), F(0), 1-F(s, 20)))
        for x, y in (same_fiber, other):
            assert posterior_equivalent_for_pair(hmm, x, y)[0] == posterior_equivalent_bruteforce(hmm, x, y)[0]


def test_fast_equivalence_counterexample_is_genuine(finance):
    hmm = finance.hmm()
    x, y = (F(1, 3),)*3, (F(1, 2), F(1, 4), F(1, 4))
    equal, word = posterior_equivalent_for_pair(hmm, x, y)
    assert not equal and len(word) <= hmm.S**2-1
    assert hmm.target(word, x) != hmm.target(word, y)
    assert posterior_equivalent_for_pair(hmm, x, x) == (True, None)


def test_settings_accept_exact_strings():
    s = SolverSettings(alpha="1/20", epsilon="0.005")
    assert s.alpha == F(1, 20) and s.epsilon == F(1, 200)
    with pytest.raises(TypeError):
        SolverSettings(alpha=0.05)


def test_cli_paper_indexed(tmp_path, capsys):
    from hmmcert.__main__ import main
    obs = tmp_path/"obs.json"
    obs.write_text("[1, 2, 2, 1, 2, 1]")
    out = tmp_path/"c.json"
    main(["certify", "--model", str(ROOT/"examples"/"rank_deficient.json"),
          "--observations", str(obs), "--paper-indexed", "--output", str(out)])
    cert = json.loads(out.read_text())
    assert cert["result"]["observations"] == [0, 1, 1, 0, 1, 0]
    obs.write_text("[1, 3]")
    with pytest.raises(SystemExit, match="1..2"):
        main(["certify", "--model", str(ROOT/"examples"/"rank_deficient.json"),
              "--observations", str(obs), "--paper-indexed"])
