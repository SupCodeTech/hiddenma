from fractions import Fraction as F
from copy import deepcopy
import pytest
from hmmcert.bernstein import (coefficient_vectors_integer,coefficient_vectors_rational,
  coefficient_ratios, region_oracle, forgetting_upper, cell_enclosure)
from hmmcert.geometry import Cell,refresh_vertices,triangulate,UnsupportedGeometry
from hmmcert.solver import solve,SolverSettings
from hmmcert.certificate import build_certificate,verify_certificate
from hmmcert.exact import dot


def test_integer_lift_equals_rationals(model):
    hmm=model.hmm()
    cell=Cell(((F(1),F(0),F(0)),(F(0),F(1),F(0)),(F(0),F(0),F(1))))
    suffix=[0,1,0,1,1,0]
    a=coefficient_vectors_integer(hmm,cell,suffix,hmm.prior)
    b=coefficient_vectors_rational(hmm,cell,suffix,hmm.prior)
    assert a.keys()==b.keys()
    assert all(tuple(F(x,sum(v)) for x in v)==tuple(F(y,sum(b[k])) for y in b[k])
               for k,v in a.items())
    assert coefficient_ratios(hmm.score,a)==coefficient_ratios(hmm.score,b)


def test_forgetting_controls_full_history(model):
    hmm=model.hmm()
    cell=Cell(((F(1),F(0),F(0)),(F(0),F(1),F(0)),(F(0),F(0),F(1))))
    obs=[0,1,0,1,1,0,1,0,0,1,1,0,1,0,1,0,0,1,1,1]
    E=forgetting_upper(hmm,cell,9,len(obs))
    assert E>=0
    for theta in [(F(0),F(0),F(1)),(F(1,3),)*3,(F(3,10),F(3,10),F(2,5))]:
        full=hmm.target(obs,theta)
        suffix=hmm.target(obs[-9:],theta)
        assert abs(full-suffix)<=E


def test_solver_actual_sample_point_inside_outer_and_bounds(model):
    obs=[0,1,1,0,1,0,0,1,1,0]
    result=solve(model,obs,SolverSettings(epsilon=F(1,200),max_memory=12,max_cells=40))
    assert result.status=='certified'
    L,U,inner_L,inner_U=result.bounds
    for a in range(0,11):
        for b in range(0,11-a):
            theta=(F(a,10),F(b,10),1-F(a+b,10))
            v=model.hmm().target(obs,theta)
            assert L<=v<=U
    assert L<=inner_L and inner_U<=U
    assert max(result.gaps)<=F(1,200)
    assert verify_certificate(build_certificate(model,result))["valid"]


def test_budget_exhaustion_not_falsely_certified(model):
    obs=[0,1,0,1,0,1,1,0,0,1,1,0]*3
    result=solve(model,obs,SolverSettings(epsilon=F(1,10**8),max_memory=3,max_cells=1))
    assert result.status=='resource-limited'
    assert max(result.gaps)>F(1,10**8)
    assert verify_certificate(build_certificate(model,result))["valid"]


def test_tampering_is_detected(model):
    result=solve(model,[0,1,1,0,0],SolverSettings())
    cert=build_certificate(model,result)
    bad=deepcopy(cert)
    bad['result']['observations'][0]=1
    with pytest.raises(ValueError,match="SHA-256"):
        verify_certificate(bad)


def test_1d_segment_and_point_geometry(model):
    cell=Cell(((F(1),F(0),F(0)),(F(0),F(1),F(0))))
    l,r=cell.split()
    assert (F(1,2),F(1,2),F(0)) in l.vertices
    assert (F(1,2),F(1,2),F(0)) in r.vertices
    assert Cell(((F(1,3),)*3,)).diameter_sq()==0


def test_finance_certification(finance):
    obs=[0,1,2,3,0,2,3,1,0,0]
    result=solve(finance,obs,SolverSettings(epsilon=F(1,200),max_memory=12,max_cells=48))
    assert result.status in ('certified','resource-limited')
    assert verify_certificate(build_certificate(finance,result))['valid']


def test_clipped_polygon_verified_and_initial_cell_budget(model):
    obs=[1]*4400+[0]*5600
    vertices=refresh_vertices(model,obs)
    assert len(vertices)==4
    cells=triangulate(vertices)
    assert len(cells)==2
    assert all(len(cell.vertices)==3 for cell in cells)
    too_small=solve(model,obs,SolverSettings(max_cells=1))
    assert too_small.status=='resource-limited' and too_small.bounds is None
    assert verify_certificate(build_certificate(model,too_small))["valid"]


def test_identifiable_two_mode_segment(finance):
    from hmmcert.model import AffineRefresh
    m=AffineRefresh(finance.rho,finance.P,(finance.pis[0],finance.pis[2]),
                    finance.emissions,finance.prior,finance.score)
    obs=[0,1,3,0,2,3,1,0]
    vertices=refresh_vertices(m,obs)
    assert len(vertices)==2
    assert len(vertices[0])==2
    result=solve(m,obs,SolverSettings(epsilon=F(1,200),max_memory=10,max_cells=32))
    assert result.status in ("certified","resource-limited")
    assert verify_certificate(build_certificate(m,result))["valid"]


def test_convex_polygon_fan_area_equal(model):
    def triangle_area(a,b,c):
        x,y,z=a[:2],b[:2],c[:2]
        return abs((y[0]-x[0])*(z[1]-x[1])-(y[1]-x[1])*(z[0]-x[0]))/2
    vertices=refresh_vertices(model,[1]*4400+[0]*5600)
    fan=triangulate(vertices)
    assert len(fan)==2
    a=sum((triangle_area(*cell.vertices) for cell in fan),F(0))
    b=sum((triangle_area(vertices[0],vertices[i],vertices[i+1])
           for i in range(1,len(vertices)-1)),F(0))
    assert a==b and a>0
