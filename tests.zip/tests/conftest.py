import json
from pathlib import Path
import pytest
from hmmcert import AffineRefresh

ROOT=Path(__file__).resolve().parents[1]

@pytest.fixture
def model():
    return AffineRefresh.from_dict(json.loads((ROOT/'examples'/'rank_deficient.json').read_text()))

@pytest.fixture
def finance():
    return AffineRefresh.from_dict(json.loads((ROOT/'examples'/'finance.json').read_text()))

@pytest.fixture
def four_mode():
    return AffineRefresh.from_dict(json.loads((ROOT/'examples'/'four_mode.json').read_text()))
