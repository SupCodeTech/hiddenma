"""Exact rational arithmetic and provably outward transcendental enclosures.

Only the standard library is used in the core; decimal-looking inputs are parsed
as rational numbers, not as binary floats.
"""
from __future__ import annotations
from fractions import Fraction as F
from functools import reduce
from math import gcd, isqrt


def frac(value):
    if isinstance(value, F):
        return value
    if isinstance(value, float):
        raise TypeError("Binary float is not a certified input; use a decimal string")
    return F(str(value))


def parse_matrix(matrix):
    return tuple(tuple(frac(v) for v in row) for row in matrix)


def serialize(obj):
    if isinstance(obj, F):
        return str(obj)
    if isinstance(obj, (tuple, list)):
        return [serialize(x) for x in obj]
    if isinstance(obj, dict):
        return {str(k): serialize(v) for k, v in obj.items()}
    return obj


def lcm(a: int, b: int) -> int:
    return a // gcd(a, b) * b


def lcm_denominators(numbers) -> int:
    return reduce(lcm, (x.denominator for x in numbers), 1)


def ceil_fraction(x: F) -> int:
    return -(-x.numerator // x.denominator)


def sqrt_upper(x: F, digits: int = 18) -> F:
    """Exact rational upper bound on sqrt(x), denominator 10**digits."""
    if x < 0:
        raise ValueError("sqrt of negative")
    scale = 10 ** digits
    candidate = isqrt((x.numerator * scale * scale) // x.denominator)
    if candidate * candidate * x.denominator < x.numerator * scale * scale:
        candidate += 1
    return F(candidate, scale)


def ceil_log2(x: F) -> int:
    """Smallest nonnegative integer n with 2**n >= x, x>=1."""
    if x < 1:
        raise ValueError("expected x >= 1")
    n = max(0, x.numerator.bit_length() - x.denominator.bit_length())
    while F(2 ** n) < x:
        n += 1
    while n > 0 and F(2 ** (n - 1)) >= x:
        n -= 1
    return n


def _log_near_one_upper(x: F, n_terms: int) -> F:
    """Upper bound on log(x) for 1<=x<=2 using atanh+tail bound."""
    z = (x - 1) / (x + 1)
    z2 = z*z
    power = z
    total = F(0)
    for j in range(n_terms):
        total += power / (2*j + 1)
        power *= z2
    # remaining 1/(2j+1) <= 1/(2*n_terms+1)
    total += power / ((2*n_terms + 1) * (1 - z2))
    return 2 * total


def log_upper(x: F, n_terms: int = 20) -> F:
    """Provable rational upper bound on log(x), x>=1; no floating math."""
    if x < 1:
        raise ValueError("log bound requires x >= 1")
    if x == 1:
        return F(0)
    exponent = max(0, x.numerator.bit_length() - x.denominator.bit_length())
    while x < (2**exponent):
        exponent -= 1
    while x >= (2**(exponent + 1)):
        exponent += 1
    reduced = x / (2**exponent)
    return exponent * _log_near_one_upper(F(2), n_terms) + _log_near_one_upper(reduced, n_terms)


def dot(a, b):
    return sum((x*y for x,y in zip(a,b)), F(0))


def matvec(mat, v):
    return tuple(dot(row, v) for row in mat)


def rowvec_mat(v, mat):
    return tuple(sum((v[i] * mat[i][j] for i in range(len(v))), F(0)) for j in range(len(mat[0])))


def solve_linear(A, b):
    """Exact Gaussian elimination for nonsingular rational square matrices."""
    n = len(A)
    aug = [list(A[i]) + [b[i]] for i in range(n)]
    for i in range(n):
        pivot = next((j for j in range(i,n) if aug[j][i] != 0), None)
        if pivot is None:
            raise ValueError("singular linear system")
        aug[i],aug[pivot] = aug[pivot],aug[i]
        z = aug[i][i]
        aug[i] = [v/z for v in aug[i]]
        for j in range(n):
            if j == i:
                continue
            z = aug[j][i]
            if z:
                aug[j] = [u - z*v for u,v in zip(aug[j],aug[i])]
    return tuple(row[-1] for row in aug)
