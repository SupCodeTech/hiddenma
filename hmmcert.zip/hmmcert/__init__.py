"""Runnable exact-arithmetic research implementation of the uploaded HMM paper.

Certified global optimization supports any number K>=2 of transition modes
for rational, strictly positive affine-refresh HMMs (cost grows quickly with K
and the memory window). Other general-model facilities have explicit, limited
scopes as described in README.md.
"""
__version__="0.2.0"
from .exact import frac
from .model import RationalHMM, AffineRefresh
from .confidence import (refresh_radii, in_refresh_region, block_radius,
                         in_block_region, lr_ratio, in_lr_region)
from .geometry import refresh_vertices, refresh_region, UnsupportedGeometry
from .solver import solve, SolverSettings
from .certificate import build_certificate, verify_certificate

__all__=["frac","RationalHMM","AffineRefresh","refresh_radii", "in_refresh_region",
         "block_radius","in_block_region","lr_ratio","in_lr_region",
         "refresh_vertices","refresh_region","UnsupportedGeometry","solve","SolverSettings",
         "build_certificate","verify_certificate"]
