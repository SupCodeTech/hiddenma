"""Shared-mixture positive HMM and affine-refresh specialization.

Convention from the manuscript: draw X_0~p0; each time step draw
X_t~K_theta[X_(t-1),:] and then Y_t~G[X_t,:].
"""
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction as F
from random import Random
from .exact import frac, parse_matrix, dot, rowvec_mat, solve_linear, serialize


def _stochastic(m, name):
    if not m or not m[0]:
        raise ValueError(f"{name} empty")
    width = len(m[0])
    if any(len(r) != width for r in m):
        raise ValueError(f"{name} ragged")
    if any(v <= 0 for r in m for v in r):
        raise ValueError(f"{name} not strictly positive")
    if any(sum(r) != 1 for r in m):
        raise ValueError(f"{name} row sums must be exactly one")


def _prob(v, name):
    if not v or any(z <= 0 for z in v) or sum(v) != 1:
        raise ValueError(f"{name} must be a strictly positive probability vector")


@dataclass(frozen=True)
class RationalHMM:
    modes: tuple
    emissions: tuple
    prior: tuple
    score: tuple

    def __post_init__(self):
        if not self.modes:
            raise ValueError("at least one mode")
        s = len(self.prior)
        if s < 2 or len(self.score) != s or len(self.emissions) != s:
            raise ValueError("incompatible number of states")
        _prob(self.prior, "prior")
        _stochastic(self.emissions, "emissions")
        for m in self.modes:
            if len(m) != s or any(len(r) != s for r in m):
                raise ValueError("transition dimensions")
            _stochastic(m, "transition")

    @classmethod
    def from_dict(cls, raw):
        return cls(
            tuple(parse_matrix(m) for m in raw["modes"]),
            parse_matrix(raw["emissions"]),
            tuple(frac(v) for v in raw["prior"]),
            tuple(frac(v) for v in raw["score"]),
        )

    def to_dict(self):
        return serialize({"modes":self.modes, "emissions":self.emissions,
                          "prior":self.prior, "score":self.score})

    @property
    def S(self): return len(self.prior)
    @property
    def K(self): return len(self.modes)
    @property
    def b(self): return len(self.emissions[0])

    def theta(self, weights):
        w = tuple(frac(v) for v in weights)
        if len(w) != self.K or any(v < 0 for v in w) or sum(w) != 1:
            raise ValueError("mixture weights must be on the simplex")
        return w

    def transition(self, weights):
        w = self.theta(weights)
        return tuple(tuple(sum((w[j] * self.modes[j][i][k] for j in range(self.K)), F(0))
                           for k in range(self.S)) for i in range(self.S))

    def filter(self, observations, weights, start=None):
        """Exact *normalized* filtering; returns posterior and prefix likelihood.

        Normalizing at every step avoids an unnormalized exponential range.
        """
        K = self.transition(weights)
        p = tuple(self.prior if start is None else (frac(x) for x in start))
        z = F(1)
        for a in observations:
            if not isinstance(a, int) or not 0 <= a < self.b:
                raise ValueError(f"observation index {a} outside [0,{self.b})")
            unnorm = tuple(self.emissions[i][a] * sum((K[k][i]*p[k] for k in range(self.S)), F(0))
                           for i in range(self.S))
            prob = sum(unnorm)
            z *= prob
            p = tuple(v/prob for v in unnorm)
        return p, z

    def target(self, observations, weights, start=None):
        p,_ = self.filter(observations, weights, start=start)
        return dot(self.score, p)

    def stationary(self, weights):
        K = self.transition(weights)
        n = self.S
        A = [[K[i][j] - (F(1) if i == j else F(0)) for i in range(n)] for j in range(n)]
        A[-1] = [F(1)]*n
        rhs = [F(0)]*(n-1)+[F(1)]
        return solve_linear(A, rhs)

    def stationary_block_prob(self, weights, word):
        p = self.stationary(weights)
        return self.filter(word, weights, start=p)[1]

    def sample(self, weights, t, seed=1):
        """Return (observations, latent states) using deterministic Python Random."""
        if t < 0: raise ValueError("t < 0")
        rng = Random(seed)
        mat = self.transition(weights)
        def draw(v):
            x = rng.random()
            z = 0.0
            for i,p in enumerate(v):
                z += float(p)
                if x < z: return i
            return len(v)-1
        state = draw(self.prior)
        obs, states = [], []
        for _ in range(t):
            state = draw(mat[state])
            obs.append(draw(self.emissions[state]))
            states.append(state)
        return obs, states


@dataclass(frozen=True)
class AffineRefresh:
    rho: F
    P: tuple
    pis: tuple
    emissions: tuple
    prior: tuple
    score: tuple

    def __post_init__(self):
        if self.rho < 0 or self.rho >= 1:
            raise ValueError("rho must be in [0,1)")
        s=len(self.prior)
        _stochastic(self.P, "P")
        for i,pi in enumerate(self.pis):
            _prob(pi, f"pi{i}")
            if len(pi)!=s: raise ValueError("pi dimension mismatch")
        # Uses RationalHMM validation for the remaining requirements
        _ = self.hmm()

    @classmethod
    def from_dict(cls, raw):
        return cls(frac(raw["rho"]), parse_matrix(raw["P"]),
                   tuple(tuple(frac(v) for v in pi) for pi in raw["pis"]),
                   parse_matrix(raw["emissions"]),
                   tuple(frac(v) for v in raw["prior"]),
                   tuple(frac(v) for v in raw["score"]))

    def to_dict(self):
        return serialize({"rho":self.rho, "P":self.P, "pis":self.pis,
                          "emissions":self.emissions, "prior":self.prior,
                          "score":self.score})

    def hmm(self):
        s=len(self.prior)
        modes=tuple(tuple(tuple(self.rho*self.P[i][k]+(1-self.rho)*pi[k]
                                    for k in range(s)) for i in range(s)) for pi in self.pis)
        return RationalHMM(modes,self.emissions,self.prior,self.score)

    def stationary_modes(self):
        """Exact mu_j = (1-rho)*pi_j*(I-rho P)^(-1)."""
        s=len(self.prior)
        A=[[ (F(1) if i==j else F(0)) - self.rho*self.P[j][i]
            for j in range(s)] for i in range(s)]
        return tuple(solve_linear(A, tuple((1-self.rho)*p for p in pi)) for pi in self.pis)

    def signature_modes(self):
        mus=self.stationary_modes()
        return tuple(tuple(sum((mu[i]*self.emissions[i][a] for i in range(len(mu))), F(0))
                           for a in range(len(self.emissions[0]))) for mu in mus)

    def signature(self, weights):
        w=self.hmm().theta(weights)
        q=self.signature_modes()
        return tuple(sum((w[j]*q[j][a] for j in range(len(w))), F(0))
                     for a in range(len(q[0])))
