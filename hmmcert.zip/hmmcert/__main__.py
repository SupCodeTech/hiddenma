"""python -m hmmcert demo | certify | verify | inspect"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from fractions import Fraction as F
from .model import AffineRefresh
from .solver import solve,SolverSettings
from .certificate import build_certificate,verify_certificate,load_certificate,save_certificate
from .exact import frac
from .geometry import diameter_approx


def _print_summary(model,result,output):
    print("status:",result.status)
    print("observations:",len(result.observations),"cells:",len(result.cells))
    if result.bounds is not None:
        L,U,Lbar,Uunder=result.bounds
        print(f"outer posterior interval: [{float(L):.9f}, {float(U):.9f}]")
        if len(str(L))+len(str(U))<=240:
            print(f"exact endpoints: [{L}, {U}]")
        else:
            print("exact endpoints: see complete rational values in certificate JSON")
        print(f"lower and upper extremum gaps: {float(result.gaps[0]):.9f}, {float(result.gaps[1]):.9f}")
        print(f"parameter diameter: {diameter_approx(result.vertices):.6f}")
        print(f"signature diameter: {diameter_approx(result.vertices,model.signature):.6f}")
    if output:print("certificate:",output)


def main(argv=None):
    parser=argparse.ArgumentParser(description="Certified time-uniform HMM example")
    commands=parser.add_subparsers(dest="command",required=True)
    demo=commands.add_parser("demo",help="sample observations and generate a replayable certificate")
    demo.add_argument("--model",default="rank_deficient",choices=["rank_deficient","finance","four_mode"])
    demo.add_argument("--length",type=int,default=12)
    demo.add_argument("--seed",type=int,default=20261121)
    demo.add_argument("--output",default="demo_certificate.json")
    certified=commands.add_parser("certify",help="read JSON model and 0-indexed observation JSON")
    certified.add_argument("--model",required=True)
    certified.add_argument("--observations",required=True)
    certified.add_argument("--output",default="certificate.json")
    certified.add_argument("--paper-indexed",action="store_true",
        help="observations use the paper's 1-based symbols (e.g. Y=1+2V+C in 1..4)")
    for p in [demo,certified]:
        p.add_argument("--alpha",default="1/20")
        p.add_argument("--epsilon",default="1/200")
        p.add_argument("--max-memory",type=int,default=18)
        p.add_argument("--max-cells",type=int,default=48)
        p.add_argument("--denominator",type=int,default=None)
        p.add_argument("--max-seconds",type=float,default=None)
    verify=commands.add_parser("verify",help="independently replay JSON certificate")
    verify.add_argument("path")
    verify.add_argument("--no-cross-check",action="store_true",
        help="skip the independent volume / feasibility / rational-recurrence checks")
    inspect=commands.add_parser("inspect",help="print a model's mode and signature information")
    inspect.add_argument("path")
    args=parser.parse_args(argv)
    if args.command=="verify":
        print(json.dumps(verify_certificate(load_certificate(args.path),cross_check=not args.no_cross_check),
                         ensure_ascii=False,indent=2));return
    if args.command=="inspect":
        model=AffineRefresh.from_dict(json.loads(Path(args.path).read_text(encoding="utf8")))
        print("hidden states",model.hmm().S,"modes",model.hmm().K,"alphabet",model.hmm().b)
        print("signatures",[[str(v) for v in q] for q in model.signature_modes()]);return
    if args.command=="demo":
        data_dir=Path(__file__).resolve().parent/"data"
        model=AffineRefresh.from_dict(json.loads((data_dir/(args.model+".json")).read_text()))
        if args.length<1:raise ValueError("length must be >=1")
        K=len(model.pis)
        theta=(F(3,10),F(3,10),F(2,5)) if args.model=="rank_deficient" else tuple(F(1,K) for _ in range(K))
        obs,states=model.hmm().sample(theta,args.length,args.seed)
        print("generated observations (0-indexed):",obs)
        print("generating weights:",', '.join(map(str,theta)))
        print("true conditional target:",float(model.hmm().target(obs,theta)))
    else:
        model=AffineRefresh.from_dict(json.loads(Path(args.model).read_text(encoding="utf8")))
        obs=json.loads(Path(args.observations).read_text(encoding="utf8"))
        if not isinstance(obs,list) or not all(isinstance(a,int) and not isinstance(a,bool) for a in obs):
            raise SystemExit("observations must be a JSON array of integers")
        b=len(model.emissions[0])
        first=1 if args.paper_indexed else 0
        bad=sorted({a for a in obs if not first<=a<first+b})
        if bad:
            raise SystemExit(f"symbols must lie in {first}..{first+b-1}; offending values: {bad}")
        obs=[a-first for a in obs]
    settings=SolverSettings(alpha=frac(args.alpha),epsilon=frac(args.epsilon),
        denominator=args.denominator,max_memory=args.max_memory,max_cells=args.max_cells,
        max_seconds=args.max_seconds)
    result=solve(model,obs,settings)
    cert=build_certificate(model,result)
    save_certificate(cert,args.output)
    _print_summary(model,result,args.output)
    replay=verify_certificate(cert)
    print("replay verification:","OK" if replay["valid"] else "FAILED")

if __name__=="__main__":main()
