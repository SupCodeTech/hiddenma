"""Replayable JSON certificates with exact rational comparisons and SHA-256.

Verification reconstructs the confidence polytope from the raw observations,
replays every midpoint split from the initial exact triangulation, and
recomputes each cell's Bernstein and forgetting enclosures. With
cross_check=True (default) it additionally performs checks that do not reuse
the solver's own code path:

* every cell vertex is re-tested against the defining inequalities;
* the cells' total volume must equal the region volume computed by a different
  method (interval length / shoelace formula / pulling from the opposite apex);
* all Bernstein bounds are recomputed with the Fraction recurrence and must
  equal the integer-lift values exactly (integer-lift invariance).
"""
from __future__ import annotations
from fractions import Fraction as F
from hashlib import sha256
from json import dumps, load, dump
from .model import AffineRefresh
from .geometry import Cell, refresh_region, free_constraints, simplex_volume, region_volume
from .bernstein import cell_enclosure
from .solver import SolverSettings, _aggregate
from .exact import frac, dot

SCHEMAS=("hmmcert-v1","hmmcert-v2")


def _canonical(obj):
    return dumps(obj,sort_keys=True,ensure_ascii=False,separators=(',',':'))


def build_certificate(model, result):
    from . import __version__
    obj={"schema":"hmmcert-v2","generator":f"hmmcert {__version__}",
         "model":model.to_dict(),"result":result.as_dict()}
    obj["sha256"] = sha256(_canonical(obj).encode('utf-8')).hexdigest()
    return obj


def save_certificate(obj,path):
    with open(path,'w',encoding='utf-8') as f:
        dump(obj,f,ensure_ascii=False,indent=2)
        f.write('\n')


def load_certificate(path):
    with open(path,encoding='utf-8') as f:return load(f)


def _vecs_equal_serialized(expected,actual):
    return [[str(x) for x in row] for row in expected]==actual


def verify_certificate(cert, cross_check=True):
    data=dict(cert)
    digest=data.pop("sha256",None)
    if digest!=sha256(_canonical(data).encode('utf-8')).hexdigest():
        raise ValueError("SHA-256 mismatch")
    if data.get("schema") not in SCHEMAS:raise ValueError("unknown certificate schema")
    model=AffineRefresh.from_dict(data["model"])
    raw=data["result"]
    s=raw["settings"]
    settings=SolverSettings(alpha=frac(s["alpha"]),epsilon=frac(s["epsilon"]),
        denominator=s["denominator"],max_memory=int(s["max_memory"]),
        max_cells=int(s["max_cells"]))
    obs=tuple(raw["observations"])
    vertices,cells=refresh_region(model,obs,settings.alpha,settings.denominator)
    if not _vecs_equal_serialized(vertices,raw["vertices"]):
        raise ValueError("confidence polytope vertices mismatch")
    cells=list(cells)
    initial_cell_count=len(cells)
    for event in raw["trace"]:
        idx=event["split_index"]
        if not isinstance(idx,int) or idx<0 or idx>=len(cells):
            raise ValueError("invalid split index")
        left,right=cells[idx].split()
        cells[idx:idx+1]=[left,right]
    if [ [[str(w) for w in v] for v in c.vertices] for c in cells]!=raw["cells"]:
        raise ValueError("cell cover differs from recorded split trace")
    if len(cells)>settings.max_cells:
        if not (initial_cell_count>settings.max_cells and not raw["trace"]
                and raw["bounds"] is None and raw["gaps"] is None
                and raw["status"]=="resource-limited"):
            raise ValueError("cell budget exceeded")
        return {"valid":True,"status":"resource-limited","cells":len(cells),
                "reason":"initial exact triangulation exceeds cell budget"}
    if not cells:
        if raw["status"]!="empty-region" or raw["bounds"] is not None:
            raise ValueError("inconsistent empty-region status")
        return {"valid":True,"status":"empty-region","cells":0}
    checks=[]
    if cross_check:
        rows=free_constraints(model,obs,settings.alpha,settings.denominator)
        for cell in cells:
            for w in cell.vertices:
                if any(z<0 for z in w) or sum(w)!=1 or any(dot(c,w[:-1])>r for c,r in rows):
                    raise ValueError("a cell vertex lies outside the confidence polytope")
        checks.append("cell vertices feasible")
        reference=region_volume(model,obs,settings.alpha,settings.denominator)
        if reference>0:
            if sum((simplex_volume(c) for c in cells),F(0))!=reference:
                raise ValueError("cells do not have the volume of the confidence polytope")
            checks.append("cover volume equals independently computed region volume")
    stats=[cell_enclosure(model.hmm(),cell,obs,settings.max_memory) for cell in cells]
    if cross_check:
        rational=[cell_enclosure(model.hmm(),cell,obs,settings.max_memory,arithmetic="rational")
                  for cell in cells]
        if rational!=stats:
            raise ValueError("integer and rational Bernstein recurrences disagree")
        checks.append("integer lift equals rational recurrence")
    bounds,gaps=_aggregate(stats)
    if [str(v) for v in bounds]!=raw["bounds"]:
        raise ValueError("endpoint certificate values changed")
    if [str(v) for v in gaps]!=raw["gaps"]:
        raise ValueError("gap certificate values changed")
    status=raw["status"]
    if status=="certified" and max(gaps)>settings.epsilon:
        raise ValueError("certified status without both tolerances")
    if status not in ("certified","resource-limited"):
        raise ValueError("unexpected status")
    return {"valid":True,"status":status,"cells":len(cells),
            "outer_interval": [str(bounds[0]),str(bounds[1])],
            "gap_lower":str(gaps[0]),"gap_upper":str(gaps[1]),
            "independent_checks":checks}
