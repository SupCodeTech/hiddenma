"""Observation-only confidence sequences from manuscript sections 4.1--4.3.

The rationalized affine-refresh region is certified as a rational polygon
for K<=3. General block and LR methods expose exact membership tests, NOT
unsupported black-box polynomial optimization.
"""
from __future__ import annotations
from collections import Counter
from fractions import Fraction as F
from itertools import product
from .exact import frac, sqrt_upper, log_upper, ceil_log2, ceil_fraction


def refresh_radii(model, obs, alpha=F(1,20), denominator=None):
    t=len(obs)
    if t<1: raise ValueError("at least one observation required")
    alpha=frac(alpha)
    if not 0<alpha<1: raise ValueError("alpha must be in (0,1)")
    b=len(model.emissions[0])
    if any(a<0 or a>=b for a in obs): raise ValueError("invalid observation")
    Q=10**6*t if denominator is None else int(denominator)
    if Q<t: raise ValueError("Q_t must be >= t")
    # H = 7/10 * ceil(log2(20*b*t*t/(3*alpha)))
    H=F(7,10)*ceil_log2(F(20*b*t*t, 3)/alpha)
    result=[]
    for a in range(b):
        col=[row[a] for row in model.emissions]
        R=max(col)-min(col)
        eta_hi=sqrt_upper(H/(2*t)) + R/F((1-model.rho)*t) * (
            sqrt_upper(F((t-1)*H,2))+1)
        eta_hi=min(F(1),eta_hi)
        result.append(min(F(1), F(ceil_fraction(eta_hi*Q),Q)))
    return tuple(result)


def empirical_frequencies(observations, b):
    t=len(observations)
    if t==0: raise ValueError("empty prefix")
    c=Counter(observations)
    if any(a<0 or a>=b for a in observations):
        raise ValueError("invalid observation")
    return tuple(F(c[a],t) for a in range(b))


def frequency_constraints(model, observations, alpha=F(1,20), denominator=None):
    """Return inequalities sum_j a_j*theta_j<= bound, all rational."""
    modes=model.signature_modes()
    b=len(modes[0])
    empirical=empirical_frequencies(observations,b)
    eta=refresh_radii(model,observations,alpha,denominator)
    constraints=[]
    for a in range(b):
        q=tuple(modes[j][a] for j in range(len(modes)))
        constraints.append((q,empirical[a]+eta[a]))
        constraints.append((tuple(-z for z in q),-empirical[a]+eta[a]))
    return constraints


def in_refresh_region(model, observations, weights, alpha=F(1,20), denominator=None):
    weights=model.hmm().theta(weights)
    return all(sum((a*w for a,w in zip(coeffs,weights)),F(0)) <= bound
               for coeffs,bound in frequency_constraints(model,observations,alpha,denominator))


def block_radius(hmm, t, B, alpha=F(1,20)):
    """Rational outward envelope of Eq. (feature-radius)."""
    alpha=frac(alpha)
    if B<1 or t<B or not 0<alpha<1: raise ValueError("bad t/B/alpha")
    N=sum(hmm.b**ell for ell in range(1,B+1))
    a_minus=min(v for mat in hmm.modes for row in mat for v in row)
    one_minus_delta=hmm.S*a_minus
    logarg=F(2*N*t*(t+1),1)/alpha
    logbound=log_upper(logarg)
    ans=F(0)
    for ell in range(1,B+1):
        n=t-ell+1
        radius=F(ell,one_minus_delta*n)*sqrt_upper(F(t+1,2)*logbound)
        radius+=F(1,one_minus_delta*n)
        ans=max(ans,radius)
    return ans


def empirical_blocks(obs,B,b=None):
    t=len(obs)
    if not 1<=B<=t: raise ValueError("bad B")
    if b is None:
        b=max(obs)+1
    results={}
    for ell in range(1,B+1):
        count=Counter(tuple(obs[i:i+ell]) for i in range(t-ell+1))
        for word in product(range(b), repeat=ell):
            results[word]=F(count[word],t-ell+1)
    return results


def in_block_region(hmm,obs,weights,B=1,alpha=F(1,20)):
    """Exact check of sufficient time-uniform block confidence region."""
    weights=hmm.theta(weights)
    radius=block_radius(hmm,len(obs),B,alpha)
    freq=empirical_blocks(obs,B,hmm.b)
    return all(abs(hmm.stationary_block_prob(weights,word)-hat)<=radius
               for word,hat in freq.items())


def lr_ratio(hmm, obs, weights, reference):
    """Exact mixture likelihood ratio, reference=(theta,weight) pairs fixed in advance."""
    z=hmm.filter(obs,weights)[1]
    if len(reference)==0: raise ValueError("empty reference")
    total=F(0)
    mass=F(0)
    for theta,omega in reference:
        omega=frac(omega)
        if omega<=0: raise ValueError("reference weights must be positive")
        total+=omega*hmm.filter(obs,theta)[1]
        mass+=omega
    if mass!=1: raise ValueError("reference mass must equal one")
    return total/z


def in_lr_region(hmm, obs, weights, reference, alpha=F(1,20)):
    alpha=frac(alpha)
    if not 0<alpha<1: raise ValueError("alpha must be in (0,1)")
    return lr_ratio(hmm,obs,weights,reference) <= 1/alpha
