"""Bernstein ratio certificates and exact integer lift (paper Eqs 20-26).

The positive monomial-coefficient recurrence is used. Coefficient ratios
are identical to Bernstein-basis ratios because the multinomial constants
cancel. All arithmetic is exact.
"""
from __future__ import annotations
from fractions import Fraction as F
from itertools import product
from .exact import dot, lcm_denominators, sqrt_upper, log_upper


def _vertex_transitions(hmm, cell):
    """Transition matrices K_v for every cell vertex, computed once per cell."""
    return tuple(hmm.transition(w) for w in cell.vertices)


def transition_matrices(hmm, cell, symbol, transitions=None):
    """Matrices D(a) K_v^T for each vertex v of the cell (paper Eq for c_{n,nu})."""
    s=hmm.S
    Ts=_vertex_transitions(hmm,cell) if transitions is None else transitions
    col=tuple(hmm.emissions[i][symbol] for i in range(s))
    return tuple(tuple(tuple(col[i]*T[k][i] for k in range(s)) for i in range(s)) for T in Ts)


def _recurrence(layer, mats, S, zero):
    new={}
    for multindex,vec in layer.items():
        for j,M in enumerate(mats):
            nu=list(multindex); nu[j]+=1; nu=tuple(nu)
            transformed=tuple(sum((M[i][k]*vec[k] for k in range(S)),zero) for i in range(S))
            old=new.get(nu)
            new[nu]=transformed if old is None else tuple(a+b for a,b in zip(old,transformed))
    return new


def coefficient_vectors_integer(hmm, cell, suffix, restart):
    """Fraction-free integer lift (Proposition 'Integer-lift invariance').

    Returns multi-index -> integer state vector; the common scaling
    Q_0*prod(Q_n) cancels in every coefficient ratio.
    """
    J=len(cell.vertices)
    S=hmm.S
    Ts=_vertex_transitions(hmm,cell)
    Q0=lcm_denominators(restart)
    layer={(0,)*J:tuple(int(Q0*z) for z in restart)}
    cache={}
    for a in suffix:
        if a not in cache:
            mats=transition_matrices(hmm,cell,a,Ts)
            Q=lcm_denominators(entry for M in mats for row in M for entry in row)
            cache[a]=tuple(tuple(tuple(int(Q*x) for x in row) for row in M) for M in mats)
        layer=_recurrence(layer,cache[a],S,0)
    return layer


def coefficient_vectors_rational(hmm,cell,suffix,restart):
    """Reference Fraction recurrence, used by the verifier as an independent cross-check."""
    J=len(cell.vertices)
    S=hmm.S
    Ts=_vertex_transitions(hmm,cell)
    layer={(0,)*J:tuple(restart)}
    cache={}
    for a in suffix:
        if a not in cache:
            cache[a]=transition_matrices(hmm,cell,a,Ts)
        layer=_recurrence(layer,cache[a],S,F(0))
    return layer


def coefficient_ratios(score,vectors):
    result=[]
    for h in vectors.values():
        total=sum(h)
        if total<=0:raise ArithmeticError("positive Bernstein denominator expected")
        result.append(dot(score,h)/total)
    return min(result),max(result)


def global_contraction(hmm):
    a_min=min(v for M in hmm.modes for row in M for v in row)
    a_max=max(v for M in hmm.modes for row in M for v in row)
    return (a_max-a_min)/(a_max+a_min)


def region_oracle(hmm,cell):
    """Exact cell transition entry envelopes, rational upper kappa and log R."""
    mats=[hmm.transition(v) for v in cell.vertices]
    n=hmm.S
    lo=[[min(M[i][k] for M in mats) for k in range(n)] for i in range(n)]
    hi=[[max(M[i][k] for M in mats) for k in range(n)] for i in range(n)]
    a_low=min(min(row) for row in lo)
    a_high=max(max(row) for row in hi)
    if a_low<=0:raise ArithmeticError("transition positivity violated")
    # Transposition does not affect cross-ratio supremum.
    cross_max=F(1)
    for i,j,k,l in product(range(n),repeat=4):
        cross_max=max(cross_max,(hi[i][k]*hi[j][l])/(lo[i][l]*lo[j][k]))
    if cross_max<1:raise ArithmeticError("cross ratio envelope impossible")
    root_hi=sqrt_upper(cross_max)
    # increasing function in sqrt(R), hence this rational is a safe upper bound
    kappa_reg=(root_hi-1)/(root_hi+1)
    kappa=min(global_contraction(hmm),kappa_reg)
    return kappa,a_high/a_low


def forgetting_upper(hmm,cell,m,t):
    if m>=t:return F(0)
    if m<1:raise ValueError("m must be >=1")
    kappa,R=region_oracle(hmm,cell)
    range_phi=max(hmm.score)-min(hmm.score)
    # log(R) >=0; paper's linear tanh bound is exact under outward majorants
    return min(range_phi, range_phi * log_upper(R) * kappa**(m-1)/2)


def cell_enclosure(hmm,cell,obs,max_memory=18,arithmetic="integer"):
    """(outer lower, outer upper, min witness upper, max witness lower, E, m).

    arithmetic="integer" uses the fraction-free lift; "rational" uses the
    Fraction recurrence. Both must give identical results (integer-lift invariance).
    """
    t=len(obs)
    if t==0:raise ValueError("nonempty observation word required")
    if max_memory<1:raise ValueError("max_memory <1")
    m=min(max_memory,t)
    suffix=obs[-m:]
    # For m<t use a fixed, parameter-independent restart prior.
    restart=hmm.prior
    E=forgetting_upper(hmm,cell,m,t)
    if arithmetic=="integer":
        vectors=coefficient_vectors_integer(hmm,cell,suffix,restart)
    elif arithmetic=="rational":
        vectors=coefficient_vectors_rational(hmm,cell,suffix,restart)
    else:
        raise ValueError("arithmetic must be 'integer' or 'rational'")
    bmin,bmax=coefficient_ratios(hmm.score,vectors)
    floor,ceil=min(hmm.score),max(hmm.score)
    lower=max(floor,bmin-E)
    upper=min(ceil,bmax+E)
    pointvalues=[hmm.target(suffix,w,start=restart) for w in cell.vertices]
    inner_min_upper=min(ceil,min(pointvalues)+E)
    inner_max_lower=max(floor,max(pointvalues)-E)
    if lower>inner_min_upper or inner_max_lower>upper:
        raise ArithmeticError("invalid interval/witness enclosure")
    return lower,upper,inner_min_upper,inner_max_lower,E,m
