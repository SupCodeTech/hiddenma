"""Exact rational geometry of the affine-refresh confidence polytope.

K<=3: half-plane clipping and fan triangulation (1D/2D, unchanged since v0.1).
K>=4: exact vertex enumeration and a recursive *pulling* triangulation over
the face lattice, in any dimension. Every operation uses Fraction; no floating
convex-hull routine is trusted.
"""
from __future__ import annotations
from fractions import Fraction as F
from dataclasses import dataclass
from itertools import combinations
from math import comb, factorial
from .confidence import frequency_constraints
from .exact import dot, solve_linear

MAX_VERTEX_SYSTEMS=2_000_000


class UnsupportedGeometry(Exception):
    pass


def _cross(a,b,c):
    return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])


def _clean(points):
    out=[]
    for p in points:
        if not out or p!=out[-1]:out.append(p)
    if len(out)>1 and out[0]==out[-1]:out.pop()
    if len(out)>=3:
        # Remove collinear intermediate vertices of a convex polygon
        repeat=True
        while repeat and len(out)>=3:
            repeat=False
            for i in range(len(out)):
                if _cross(out[i-1],out[i],out[(i+1)%len(out)]) == 0:
                    out.pop(i)
                    repeat=True
                    break
    if len(out)==2 and out[0]==out[1]:out.pop()
    return out


def _clip(points, a, b, c):
    if not points:return []
    def h(p):return a*p[0]+b*p[1]-c
    out=[]
    for p,q in zip(points,points[1:]+points[:1]):
        hp,hq=h(p),h(q)
        if hp<=0:out.append(p)
        if (hp<0 and hq>0) or (hp>0 and hq<0):
            ratio=hp/(hp-hq)
            out.append(tuple(p[j]+ratio*(q[j]-p[j]) for j in range(2)))
        elif hp>0 and hq==0:
            pass  # q will be emitted on its outgoing edge
    return _clean(out)


def _full_from_free(point, K):
    if K==2:return (point[0],1-point[0])
    return (point[0],point[1],1-point[0]-point[1])


def _free_from_full(w):
    return w[:-1]


def refresh_vertices(model, obs, alpha=F(1,20), denominator=None):
    K=len(model.pis)
    if K<2:
        raise UnsupportedGeometry("at least two transition modes are required")
    if K>3:
        return refresh_region(model,obs,alpha,denominator)[0]
    constraints=frequency_constraints(model,obs,alpha,denominator)
    if K==2:
        lo,hi=F(0),F(1)
        for a,rhs in constraints:
            # a0*x+a1*(1-x)<=rhs
            slope=a[0]-a[1]
            rhs-=a[1]
            if slope>0:hi=min(hi,rhs/slope)
            elif slope<0:lo=max(lo,rhs/slope)
            elif rhs<0:return tuple()
            if hi<lo:return tuple()
        if lo==hi:return ((lo,1-lo),)
        return ((lo,1-lo),(hi,1-hi))
    poly=[(F(0),F(0)),(F(1),F(0)),(F(0),F(1))]
    for a,rhs in constraints:
        # a0*x+a1*y+a2*(1-x-y)<=rhs
        poly=_clip(poly,a[0]-a[2],a[1]-a[2],rhs-a[2])
        if not poly:return tuple()
    poly=_clean(poly)
    if len(poly)>=3 and sum((_cross(poly[0],poly[i],poly[i+1]) for i in range(1,len(poly)-1)),F(0))==0:
        poly=sorted(set(poly))
        poly=[poly[0],poly[-1]]
    vertices=tuple(_full_from_free(p,3) for p in poly)
    for w in vertices:
        if any(z<0 for z in w) or sum(w)!=1:
            raise ArithmeticError("non-feasible geometry vertex")
        if any(dot(a,w)>rhs for a,rhs in constraints):
            raise ArithmeticError("clipped vertex violates a defining halfspace")
    return vertices


@dataclass(frozen=True)
class Cell:
    vertices: tuple

    def __post_init__(self):
        if not self.vertices:
            raise ValueError("a cell needs at least one vertex")
        k=len(self.vertices[0])
        if len(self.vertices)>k:
            raise ValueError("a simplex in the (K-1)-simplex has at most K vertices")
        if any(len(v)!=k or sum(v)!=1 or any(w<0 for w in v) for v in self.vertices):
            raise ValueError("invalid cell vertices")

    def split(self):
        if len(self.vertices)==1:
            raise ValueError("cannot split a point")
        v=self.vertices
        edges=[(sum(((v[i][k]-v[j][k])**2 for k in range(len(v[0]))),F(0)),i,j)
               for i in range(len(v)) for j in range(i+1,len(v))]
        _,i,j=max(edges,key=lambda x:(x[0],-x[1],-x[2]))
        m=tuple((v[i][k]+v[j][k])/2 for k in range(len(v[0])))
        left=list(v);right=list(v)
        left[i]=m
        right[j]=m
        return Cell(tuple(left)),Cell(tuple(right))

    def diameter_sq(self):
        return max((sum(((u[i]-v[i])**2 for i in range(len(u))),F(0))
                    for u in self.vertices for v in self.vertices),default=F(0))


def triangulate(vertices):
    n=len(vertices)
    if n==0:return tuple()
    if n<=3:return (Cell(tuple(vertices)),)
    return tuple(Cell((vertices[0],vertices[i],vertices[i+1])) for i in range(1,n-1))


def diameter_approx(vertices, signature=None):
    if not vertices:return 0.0
    v=vertices if signature is None else [signature(w) for w in vertices]
    return max((sum((float(a-b)**2 for a,b in zip(p,q)))**0.5 for p in v for q in v),default=0.0)


# ---------------------------------------------------------------------------
# General dimension (K>=4; also usable for K<=3 as an independent cross-check)
# ---------------------------------------------------------------------------

def free_constraints(model, obs, alpha=F(1,20), denominator=None):
    """All defining inequalities c.x <= r in free coordinates x=theta[:-1].

    Rows 0..K-2 are x_j>=0, row K-1 is theta_K>=0, then the frequency rows.
    """
    K=len(model.pis); d=K-1
    rows=[(tuple(F(-1) if i==j else F(0) for i in range(d)),F(0)) for j in range(d)]
    rows.append((tuple(F(1) for _ in range(d)),F(1)))
    for a,rhs in frequency_constraints(model,obs,alpha,denominator):
        rows.append((tuple(a[j]-a[-1] for j in range(d)),rhs-a[-1]))
    return rows


def _feasible(rows,x):
    return all(dot(c,x)<=r for c,r in rows)


def _rank(vectors):
    rows=[list(v) for v in vectors]
    rank=0
    for col in range(len(rows[0]) if rows else 0):
        piv=next((i for i in range(rank,len(rows)) if rows[i][col]!=0),None)
        if piv is None:
            continue
        rows[rank],rows[piv]=rows[piv],rows[rank]
        for i in range(len(rows)):
            if i!=rank and rows[i][col]!=0:
                f=rows[i][col]/rows[rank][col]
                rows[i]=[a-f*b for a,b in zip(rows[i],rows[rank])]
        rank+=1
    return rank


def affine_dimension(points):
    if len(points)<=1:
        return 0
    p0=points[0]
    return _rank([tuple(a-b for a,b in zip(p,p0)) for p in points[1:]])


def _det(matrix):
    m=[list(r) for r in matrix]; n=len(m); sign=1; det=F(1)
    for col in range(n):
        piv=next((i for i in range(col,n) if m[i][col]!=0),None)
        if piv is None:
            return F(0)
        if piv!=col:
            m[col],m[piv]=m[piv],m[col]; sign=-sign
        det*=m[col][col]
        for i in range(col+1,n):
            f=m[i][col]/m[col][col]
            if f:
                m[i]=[a-f*b for a,b in zip(m[i],m[col])]
    return sign*det


def enumerate_vertices(rows,d,max_systems=MAX_VERTEX_SYSTEMS):
    """Exact vertices (free coordinates, sorted) of {x: c.x<=r for all rows}.

    A point is a vertex iff it is feasible and d linearly independent rows are
    tight there, so solving every d-subset of rows is exhaustive.
    """
    corners=[tuple(F(1) if i==j else F(0) for i in range(d)) for j in range(d)]
    corners.append(tuple(F(0) for _ in range(d)))
    if all(_feasible(rows,x) for x in corners):
        return sorted(corners)          # convexity: the whole simplex is feasible
    unique=list(dict.fromkeys(rows))
    if comb(len(unique),d)>max_systems:
        raise UnsupportedGeometry(f"vertex enumeration needs {comb(len(unique),d)} exact solves; "
                                  "raise MAX_VERTEX_SYSTEMS deliberately")
    found=set()
    for idx in combinations(range(len(unique)),d):
        try:
            x=solve_linear([unique[i][0] for i in idx],[unique[i][1] for i in idx])
        except ValueError:
            continue
        if _feasible(rows,x):
            found.add(x)
    return sorted(found)


def _pulling(face,points,tight,apex_rule,memo):
    """Pulling triangulation of the face spanned by vertex ids `face`."""
    key=(face,apex_rule)
    if key in memo:
        return memo[key]
    k=affine_dimension([points[i] for i in sorted(face)])
    if len(face)==k+1:
        out=[tuple(sorted(face))]
    else:
        apex=min(face) if apex_rule=="min" else max(face)
        facets=set()
        for c in sorted(set().union(*(tight[i] for i in face))):
            G=frozenset(i for i in face if c in tight[i])
            if apex in G or G in facets or len(G)<k:
                continue
            if affine_dimension([points[i] for i in sorted(G)])==k-1:
                facets.add(G)
        out=[]
        for G in sorted(facets,key=sorted):
            for simplex in _pulling(G,points,tight,apex_rule,memo):
                out.append(tuple(sorted((apex,)+simplex)))
    memo[key]=out
    return out


def _full(x):
    return tuple(x)+(1-sum(x,F(0)),)


def general_region(model,obs,alpha=F(1,20),denominator=None,apex_rule="min"):
    """(vertices, cells) of C_obs in full coordinates, for any K>=2."""
    rows=free_constraints(model,obs,alpha,denominator)
    d=len(model.pis)-1
    points=enumerate_vertices(rows,d)
    if not points:
        return tuple(),tuple()
    tight=[frozenset(c for c,(a,r) in enumerate(rows) if dot(a,x)==r) for x in points]
    simplices=_pulling(frozenset(range(len(points))),points,tight,apex_rule,{})
    vertices=tuple(_full(x) for x in points)
    cells=tuple(Cell(tuple(vertices[i] for i in s)) for s in simplices)
    return vertices,cells


def refresh_region(model,obs,alpha=F(1,20),denominator=None):
    """Vertices and an exact simplicial cover of C_obs (dispatches on K)."""
    K=len(model.pis)
    if K<2:
        raise UnsupportedGeometry("at least two transition modes are required")
    if K<=3:
        vertices=refresh_vertices(model,obs,alpha,denominator)
        return vertices,triangulate(vertices)
    return general_region(model,obs,alpha,denominator)


def simplex_volume(cell):
    """d-volume in free coordinates (zero for lower-dimensional cells)."""
    v=[x[:-1] for x in cell.vertices]
    d=len(v[0])
    if len(v)!=d+1:
        return F(0)
    return abs(_det([tuple(a-b for a,b in zip(p,v[0])) for p in v[1:]]))/factorial(d)


def region_volume(model,obs,alpha=F(1,20),denominator=None):
    """Volume of C_obs computed WITHOUT the solver's triangulation.

    K=2: interval length; K=3: shoelace formula on the clipped polygon;
    K>=4: pulling triangulation from the *largest* vertex (the solver pulls
    from the smallest), so the two decompositions differ.
    """
    K=len(model.pis)
    if K==2:
        v=refresh_vertices(model,obs,alpha,denominator)
        return abs(v[0][0]-v[-1][0]) if v else F(0)
    if K==3:
        v=[x[:2] for x in refresh_vertices(model,obs,alpha,denominator)]
        if len(v)<3:
            return F(0)
        return abs(sum((v[i][0]*v[(i+1)%len(v)][1]-v[(i+1)%len(v)][0]*v[i][1]
                        for i in range(len(v))),F(0)))/2
    _,cells=general_region(model,obs,alpha,denominator,apex_rule="max")
    return sum((simplex_volume(c) for c in cells),F(0))
