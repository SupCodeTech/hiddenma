"""Certified branch-and-bound over rational confidence polytopes (any K>=2).

This solver's status 'certified' refers ONLY to deterministic extremum gaps.
It does not mean a fitted model is statistically correct.
"""
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction as F
from time import monotonic
from .confidence import frequency_constraints
from .geometry import Cell, refresh_region, diameter_approx
from .bernstein import cell_enclosure
from .exact import frac, serialize


@dataclass(frozen=True)
class SolverSettings:
    alpha: F=F(1,20)
    epsilon: F=F(1,200)
    denominator: int|None=None
    max_memory: int=18
    max_cells: int=48
    max_seconds: float|None=None

    def __post_init__(self):
        # accept "1/20", "0.05", ints or Fractions; binary floats are rejected by frac()
        object.__setattr__(self,"alpha",frac(self.alpha))
        object.__setattr__(self,"epsilon",frac(self.epsilon))
        if not (F(0)<self.alpha<1 and self.epsilon>0):raise ValueError("invalid alpha/epsilon")
        if self.max_cells<1 or self.max_memory<1:raise ValueError("invalid budgets")

    def to_dict(self):
        return serialize({"alpha":self.alpha,"epsilon":self.epsilon,
            "denominator":self.denominator,"max_memory":self.max_memory,
            "max_cells":self.max_cells})


@dataclass
class Result:
    status: str
    vertices: tuple
    cells: tuple
    bounds: tuple|None
    gaps: tuple|None
    trace: list
    settings: SolverSettings
    observations: tuple

    def as_dict(self):
        data={"status":self.status,"vertices":serialize(self.vertices),
              "cells":serialize([cell.vertices for cell in self.cells]),
              "bounds":serialize(self.bounds),"gaps":serialize(self.gaps),
              "trace":self.trace,"settings":self.settings.to_dict(),
              "observations":list(self.observations)}
        return data


def _aggregate(stats):
    if not stats:return None,None
    L=min(s[0] for s in stats)
    U=max(s[1] for s in stats)
    inner_L=min(s[2] for s in stats)
    inner_U=max(s[3] for s in stats)
    gaps=(inner_L-L,U-inner_U)
    if gaps[0]<0 or gaps[1]<0:raise ArithmeticError("negative extremum gap")
    return (L,U,inner_L,inner_U),gaps


def solve(model, observations, settings=SolverSettings()):
    """Produce exact rational bounds; no false 'certified' on budget exhaustion."""
    observations=tuple(observations)
    hmm=model.hmm()
    if any(a<0 or a>=hmm.b for a in observations):raise ValueError("bad observations")
    if len(observations)<1: raise ValueError("need at least one observation")
    vertices,cells=refresh_region(model,observations,settings.alpha,settings.denominator)
    if not vertices:
        return Result("empty-region",vertices,(),None,None,[],settings,observations)
    cells=list(cells)
    if len(cells)>settings.max_cells:
        return Result("resource-limited",vertices,tuple(cells),None,None,[],settings,observations)
    stats=[cell_enclosure(hmm,c,observations,settings.max_memory) for c in cells]
    deadline=None if settings.max_seconds is None else monotonic()+settings.max_seconds
    trace=[]
    while True:
        bounds,gaps=_aggregate(stats)
        if max(gaps)<=settings.epsilon:
            status="certified"
            break
        if len(cells)>=settings.max_cells or (deadline is not None and monotonic()>deadline):
            status="resource-limited"
            break
        L,U,inner_L,inner_U=bounds
        # Global-extremum candidates. Subdivide a cell affecting the larger gap;
        # favor larger local bound/witness discrepancy. All tie-breakers deterministic.
        candidates=[]
        if gaps[0]>=gaps[1]:
            candidates=[(s[2]-s[0],c.diameter_sq(),-i,i)
                        for i,(c,s) in enumerate(zip(cells,stats)) if s[0]==L and len(c.vertices)>1]
        if not candidates:
            candidates=[(s[1]-s[3],c.diameter_sq(),-i,i)
                        for i,(c,s) in enumerate(zip(cells,stats)) if s[1]==U and len(c.vertices)>1]
        if not candidates:
            candidates=[(max(s[2]-s[0],s[1]-s[3]),c.diameter_sq(),-i,i)
                        for i,(c,s) in enumerate(zip(cells,stats)) if len(c.vertices)>1]
        if not candidates:
            status="resource-limited"
            break
        idx=max(candidates)[-1]
        left,right=cells[idx].split()
        trace.append({"split_index":idx})
        cells[idx:idx+1]=[left,right]
        stats[idx:idx+1]=[cell_enclosure(hmm,left,observations,settings.max_memory),
                           cell_enclosure(hmm,right,observations,settings.max_memory)]
    bounds,gaps=_aggregate(stats)
    return Result(status,vertices,tuple(cells),bounds,gaps,trace,settings,observations)
