"""Finite-word target equivalence test (fixed parameter pair only).

Proposition (finite-word posterior equivalence): the target posteriors at two
FIXED parameters x, x' agree for every word iff Gamma_w(x,x')=0 for all words
of length <= S^2-1, where Gamma_w = c.(u_x(w) (x) u_x'(w)) and
c = phi(x)1 - 1(x)phi. Because v_w = u_x(w)(x)u_x'(w) evolves linearly, it is
enough to test c against a basis of span{v_w}; a breadth-first search that
only expands linearly independent vectors finds such a basis using words of
length <= S^2-1 (Tzeng-style). This is exact and polynomial in S and b.

This module does NOT decide the universally quantified fiber-invariance
problem over an entire polytope.
"""
from __future__ import annotations
from fractions import Fraction as F
from itertools import product
from .exact import dot


class _Echelon:
    """Exact incremental row-echelon basis over the rationals."""
    def __init__(self):
        self.rows=[]   # (pivot column, row with 1 at the pivot)

    def add(self,vec):
        v=list(vec)
        for piv,row in self.rows:
            if v[piv]:
                f=v[piv]
                v=[a-f*b for a,b in zip(v,row)]
        piv=next((i for i,x in enumerate(v) if x),None)
        if piv is None:
            return False
        z=v[piv]
        self.rows.append((piv,[x/z for x in v]))
        return True


def _advance(hmm,K,u,a):
    s=hmm.S
    w=tuple(hmm.emissions[i][a]*sum((K[k][i]*u[k] for k in range(s)),F(0)) for i in range(s))
    total=sum(w)
    return tuple(x/total for x in w)   # positive rescaling leaves Gamma_w's sign pattern unchanged


def posterior_equivalent_for_pair(hmm,theta,theta_prime,max_words=None):
    """Return (bool, counterexample word or None), via exact rational linear algebra.

    Explores at most S^2 linearly independent words (each of length <= S^2-1)
    and their b one-symbol extensions, instead of all b^(S^2-1) words.
    `max_words` is accepted for backward compatibility and ignored.
    """
    theta=hmm.theta(theta)
    theta_prime=hmm.theta(theta_prime)
    S=hmm.S
    Kx=hmm.transition(theta); Ky=hmm.transition(theta_prime)
    phi=hmm.score
    c=tuple(phi[i]-phi[j] for i in range(S) for j in range(S))
    basis=_Echelon()
    queue=[((),tuple(hmm.prior),tuple(hmm.prior))]
    head=0
    while head<len(queue):
        word,u,v=queue[head]; head+=1
        vec=tuple(a*b for a in u for b in v)
        if not basis.add(vec):
            continue
        if dot(c,vec)!=0:
            return False,word
        if len(word)>=S*S-1:
            continue
        for a in range(hmm.b):
            queue.append((word+(a,),_advance(hmm,Kx,u,a),_advance(hmm,Ky,v,a)))
    return True,None


def posterior_equivalent_bruteforce(hmm,theta,theta_prime,max_words=200000):
    """Original exhaustive enumeration, kept as an independent reference.

    Raises if the alphabet/hidden-state size makes exhaustive enumeration
    impractical instead of returning an unverified True.
    """
    max_length=hmm.S*hmm.S-1
    total=sum(hmm.b**ell for ell in range(max_length+1))
    if total>max_words:
        raise ValueError(f"requires {total} words; increase max_words deliberately")
    theta=hmm.theta(theta)
    theta_prime=hmm.theta(theta_prime)
    # Shared empty-word posterior always matches because the prior is fixed.
    for ell in range(1,max_length+1):
        for word in product(range(hmm.b),repeat=ell):
            if hmm.target(word,theta)!=hmm.target(word,theta_prime):
                return False,word
    return True,None


def sensitivity_bound(hmm):
    """Return rational kappa and float-free L_phi from Theorem 1.

    c_Q contains Euclidean norms and is generally irrational; using
    sqrt_upper yields a safe rational upper bound.
    """
    from .exact import sqrt_upper
    s=hmm.S
    d=hmm.K-1
    a_min=min(x for M in hmm.modes for row in M for x in row)
    a_max=max(x for M in hmm.modes for row in M for x in row)
    kappa=(a_max-a_min)/(a_max+a_min)
    cQ=F(0)
    for i in range(s):
        for k in range(s):
            # Q_j=(K_j-K_K).T, so Q_j[i,k]=K_j[k,i]-K_K[k,i]
            numerator=sum(((hmm.modes[j][k][i]-hmm.modes[-1][k][i])**2 for j in range(d)),F(0))
            denominator=min(hmm.modes[j][k][i] for j in range(hmm.K))
            cQ=max(cQ,sqrt_upper(numerator)/denominator)
    L=(max(hmm.score)-min(hmm.score))*cQ/(2*(1-kappa))
    return {"kappa":kappa,"c_Q_upper":cQ,"L_phi_upper":L}
